<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '02018d27f934c24f8c26dbf4be7621e7',
      'native_key' => 'jsonformbuilder',
      'filename' => 'modNamespace/d1e23a4e76fd4448f0079e0349dfd623.vehicle',
      'namespace' => 'jsonformbuilder',
    ),
  ),
);