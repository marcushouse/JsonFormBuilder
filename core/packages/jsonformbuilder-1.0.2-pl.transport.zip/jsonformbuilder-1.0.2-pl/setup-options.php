<?php
$output='<h2>JsonFormBuilder</h2>';
switch ($options[xPDOTransport::PACKAGE_ACTION]) {
    case xPDOTransport::ACTION_INSTALL:
        $output = '<p>Thanks for installing JsonFormBuilder!</p>';
        break;
    case xPDOTransport::ACTION_UPGRADE:
        $output = '<p>Thanks for upgrading JsonFormBuilder!</p>';
        break;
    case xPDOTransport::ACTION_UNINSTALL:
        $output = '<p>Sorry to see you uninstalling JsonFormBuilder!</p>';
        break;
}
$output.='<p>Please contact us at <a href="http://modxrevo.datawebnet.com.au/">our support site</a> for assistance / bug reports.</p>';

return $output;