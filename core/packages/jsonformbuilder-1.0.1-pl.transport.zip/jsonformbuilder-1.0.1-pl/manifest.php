<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '20ffd33ccdb955323766cc4f1862a912',
      'native_key' => 'jsonformbuilder',
      'filename' => 'modNamespace/2afddfcaa56259e18b0bb441c9f7ae4d.vehicle',
      'namespace' => 'jsonformbuilder',
    ),
  ),
);